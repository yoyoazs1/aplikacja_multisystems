import 'package:flutter/material.dart';

void main() => runApp(const MultisystemsApp());

class MultisystemsApp extends StatelessWidget {
  const MultisystemsApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Multisystems',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(colorSchemeSeed: Colors.blue, useMaterial3: true),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Multisystems')),
      body: const Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.ac_unit, size: 72),
            SizedBox(height: 16),
            Text('Aplikacja Multisystems', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            SizedBox(height: 8),
            Text('Projekt Flutter jest gotowy do automatycznego budowania APK w GitHub Actions.', textAlign: TextAlign.center),
          ]),
        ),
      ),
    );
  }
}
